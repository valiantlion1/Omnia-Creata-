# Omnia Organizer – Privacy Policy (v1)

Effective date: 2025-08-21
Contact: omnia.organizer.app@gmail.com

- We do not collect, store, or share any personal data on our servers.
- The app works offline-first. Your data is stored locally on your device.
- No analytics, crash reporting, or tracking are enabled by default.
- No third-party SDKs that collect personal data are integrated by default.
- Optional features that could involve data transfer (e.g., cloud sync, telemetry, AI services) are disabled in this version. If enabled in the future, they will be clearly opt-in, with a transparent explanation and updated policy.
- You can export or delete your data anytime from within the app (export/backup tools will be provided as local file operations).
- If you contact us for support, we will only use your email to respond to your inquiry.

Security
- Your data stays on-device. We plan to add optional local encryption and app lock. If a cloud feature is introduced later, we will publish clear security details.

Children’s Privacy
- The app is intended for general productivity use. We do not knowingly collect data from children.

Policy Changes
- We may update this policy as the app evolves. We will update this page with the new effective date.

If you have questions about this policy, contact us at omnia.organizer.app@gmail.com.