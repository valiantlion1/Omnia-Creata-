# OmniaOrganizer Codex Paketi

Bu klasör OmniaOrganizer için Codex'e verilecek çalışma paketini içerir.

## İçindekiler
- 4 tur rakip ve pazar analizi
- fazlı ürün blueprinti
- Codex için eksik paket analizi
- AGENTS.md
- PLAN_PHASE_1.md
- SCREEN_BEHAVIOR.md
- TECH_CONSTRAINTS.md
- FEATURE_MATRIX.csv
- ACCEPTANCE_CRITERIA.md

## Kullanım sırası
1. PRODUCT/BLUEPRINT mantığını oku
2. AGENTS.md kurallarını ana referans yap
3. TECH_CONSTRAINTS.md ile teknik sınırları uygula
4. PLAN_PHASE_1.md ile ilk üretim fazını kilitle
5. SCREEN_BEHAVIOR.md ile ekran akışını koru
6. FEATURE_MATRIX.csv ile scope creep'i engelle
7. ACCEPTANCE_CRITERIA.md ile “bitti” tanımını uygula
