import { useState } from "react";
import { useNavigate } from "react-router";
import { motion } from "motion/react";
import {
  ArrowLeft, User, Crown, Bell, Shield, Globe, Moon, Smartphone,
  ChevronRight, LogOut, Trash2, Star, HelpCircle, FileText,
  Zap, Gift, Share2, ToggleLeft, ToggleRight, Check
} from "lucide-react";

const PLAN_BADGE = {
  label: "FREE",
  color: "#8A8A9E",
  bg: "rgba(138,138,158,0.15)",
  border: "rgba(138,138,158,0.2)",
};

const themes = [
  { id: "dark", label: "Karanlık", icon: Moon, color: "#4A90D9" },
  { id: "amoled", label: "AMOLED", icon: Moon, color: "#F0F0FA" },
  { id: "light", label: "Açık", icon: Smartphone, color: "#E8A830" },
];

const languages = ["Türkçe", "English", "日本語", "Deutsch"];

type ToggleSetting = {
  id: string;
  label: string;
  desc: string;
  default: boolean;
  proOnly?: boolean;
};

const toggleSettings: ToggleSetting[] = [
  { id: "push", label: "Bildirimler", desc: "İşlem bitti uyarıları", default: true },
  { id: "email", label: "E-posta Özeti", desc: "Günlük aktivite özeti", default: false },
  { id: "ai_suggest", label: "AI Önerileri", desc: "Akıllı düzenleme ipuçları", default: true },
  { id: "local_mode", label: "Önce Yerel İşlem", desc: "Gizlilik öncelikli mod", default: true },
  { id: "analytics", label: "Kullanım Analizi", desc: "Ürünü iyileştirmemize yardım et", default: false },
  { id: "biometric", label: "Biyometrik Giriş", desc: "Parmak izi ile hızlı giriş", default: false },
];

export function SettingsScreen() {
  const navigate = useNavigate();
  const [activeTheme, setActiveTheme] = useState("dark");
  const [activeLang, setActiveLang] = useState("Türkçe");
  const [toggles, setToggles] = useState<Record<string, boolean>>(
    Object.fromEntries(toggleSettings.map((s) => [s.id, s.default]))
  );

  const toggle = (id: string) => setToggles((prev) => ({ ...prev, [id]: !prev[id] }));

  return (
    <div className="flex flex-col" style={{ background: "#060608", minHeight: "100%" }}>
      {/* Header */}
      <div className="flex items-center justify-between px-5 pt-4 pb-3">
        <div style={{ width: 36 }} />
        <span className="text-[17px] font-bold" style={{ color: "#F0F0FA", letterSpacing: "-0.01em" }}>
          Ayarlar
        </span>
        <div style={{ width: 36 }} />
      </div>

      <div className="flex-1 overflow-y-auto omnia-scroll pb-8">
        {/* Profile card */}
        <div className="px-5 mb-5">
          <motion.div
            className="rounded-2xl p-4 relative overflow-hidden"
            style={{
              background: "linear-gradient(135deg, rgba(201,168,76,0.08) 0%, rgba(201,168,76,0.03) 100%)",
              border: "1px solid rgba(201,168,76,0.15)",
            }}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.4 }}
          >
            <div className="absolute top-0 right-0 w-40 h-40 rounded-full opacity-5"
              style={{ background: "radial-gradient(circle, #C9A84C 0%, transparent 70%)", transform: "translate(30%, -30%)" }} />

            <div className="flex items-center gap-4">
              {/* Avatar */}
              <div
                className="w-14 h-14 rounded-2xl flex items-center justify-center relative"
                style={{ background: "rgba(201,168,76,0.15)", border: "1.5px solid rgba(201,168,76,0.3)" }}
              >
                <span className="text-[22px] font-extrabold" style={{ color: "#C9A84C" }}>AE</span>
                <div
                  className="absolute -bottom-1 -right-1 w-5 h-5 rounded-full flex items-center justify-center"
                  style={{ background: "#060608", border: "1px solid rgba(201,168,76,0.3)" }}
                >
                  <div className="w-3 h-3 rounded-full" style={{ background: "#3DBA8C" }} />
                </div>
              </div>

              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 mb-0.5">
                  <h2 className="text-[17px] font-extrabold" style={{ color: "#F0F0FA", letterSpacing: "-0.01em" }}>
                    Ali Erdinç Yiğitaslan
                  </h2>
                </div>
                <p className="text-[12px]" style={{ color: "#8A8A9E" }}>ghostsofter12@gmail.com</p>
                <div className="flex items-center gap-2 mt-2">
                  <span
                    className="text-[11px] font-bold px-2.5 py-1 rounded-full tracking-wide"
                    style={{ background: PLAN_BADGE.bg, color: PLAN_BADGE.color, border: `1px solid ${PLAN_BADGE.border}` }}
                  >
                    {PLAN_BADGE.label}
                  </span>
                  <button
                    onClick={() => navigate("/pricing")}
                    className="flex items-center gap-1 px-2.5 py-1 rounded-full text-[11px] font-semibold"
                    style={{ background: "rgba(201,168,76,0.15)", color: "#C9A84C", border: "1px solid rgba(201,168,76,0.25)" }}
                  >
                    <Zap size={10} />
                    Pro'ya Geç
                  </button>
                </div>
              </div>
            </div>

            {/* Credits bar */}
            <div className="mt-4">
              <div className="flex justify-between mb-1.5">
                <span className="text-[12px]" style={{ color: "#8A8A9E" }}>Günlük Kredi</span>
                <span className="text-[12px] font-bold" style={{ color: "#C9A84C" }}>8 / 10</span>
              </div>
              <div className="w-full h-1.5 rounded-full" style={{ background: "rgba(255,255,255,0.08)" }}>
                <div className="h-full rounded-full" style={{ width: "80%", background: "linear-gradient(90deg, #C9A84C, #E8C97A)" }} />
              </div>
            </div>
          </motion.div>
        </div>

        {/* Stats row */}
        <div className="px-5 mb-5">
          <div className="grid grid-cols-3 gap-2">
            {[
              { label: "Düzenleme", value: "47", color: "#C9A84C" },
              { label: "Bu Ay", value: "23", color: "#3DBA8C" },
              { label: "Kredi Kullanım", value: "186", color: "#4A90D9" },
            ].map((s) => (
              <div
                key={s.label}
                className="rounded-xl p-3 text-center"
                style={{ background: "rgba(255,255,255,0.03)", border: "1px solid rgba(255,255,255,0.06)" }}
              >
                <div className="text-[20px] font-extrabold" style={{ color: s.color }}>{s.value}</div>
                <div className="text-[10px] mt-0.5" style={{ color: "#6B6B84" }}>{s.label}</div>
              </div>
            ))}
          </div>
        </div>

        {/* Theme */}
        <div className="px-5 mb-5">
          <p className="text-[12px] font-semibold uppercase tracking-wider mb-2.5" style={{ color: "#6B6B84", letterSpacing: "0.1em" }}>
            Tema
          </p>
          <div className="flex gap-2">
            {themes.map((t) => (
              <button
                key={t.id}
                onClick={() => setActiveTheme(t.id)}
                className="flex-1 py-2.5 rounded-xl flex flex-col items-center gap-1.5"
                style={{
                  background: activeTheme === t.id ? `${t.color}15` : "rgba(255,255,255,0.03)",
                  border: activeTheme === t.id ? `1px solid ${t.color}35` : "1px solid rgba(255,255,255,0.07)",
                }}
              >
                <t.icon size={16} style={{ color: activeTheme === t.id ? t.color : "#6B6B84" }} />
                <span className="text-[11px] font-semibold" style={{ color: activeTheme === t.id ? t.color : "#6B6B84" }}>
                  {t.label}
                </span>
              </button>
            ))}
          </div>
        </div>

        {/* Language */}
        <div className="px-5 mb-5">
          <p className="text-[12px] font-semibold uppercase tracking-wider mb-2.5" style={{ color: "#6B6B84", letterSpacing: "0.1em" }}>
            Dil
          </p>
          <div className="flex gap-2 overflow-x-auto pb-1" style={{ scrollbarWidth: "none" }}>
            {languages.map((lang) => (
              <button
                key={lang}
                onClick={() => setActiveLang(lang)}
                className="shrink-0 px-4 py-2 rounded-xl text-[12px] font-semibold flex items-center gap-1.5"
                style={{
                  background: activeLang === lang ? "rgba(201,168,76,0.12)" : "rgba(255,255,255,0.03)",
                  color: activeLang === lang ? "#C9A84C" : "#6B6B84",
                  border: activeLang === lang ? "1px solid rgba(201,168,76,0.25)" : "1px solid rgba(255,255,255,0.07)",
                }}
              >
                {activeLang === lang && <Check size={11} style={{ color: "#C9A84C" }} />}
                {lang}
              </button>
            ))}
          </div>
        </div>

        {/* Toggle settings */}
        <div className="px-5 mb-5">
          <p className="text-[12px] font-semibold uppercase tracking-wider mb-3" style={{ color: "#6B6B84", letterSpacing: "0.1em" }}>
            Tercihler
          </p>
          <div
            className="rounded-2xl overflow-hidden"
            style={{ border: "1px solid rgba(255,255,255,0.07)" }}
          >
            {toggleSettings.map((s, i) => (
              <div
                key={s.id}
                className="flex items-center justify-between px-4 py-3.5"
                style={{
                  borderBottom: i < toggleSettings.length - 1 ? "1px solid rgba(255,255,255,0.05)" : "none",
                  background: i % 2 === 0 ? "rgba(255,255,255,0.02)" : "rgba(255,255,255,0.01)",
                }}
              >
                <div className="flex-1 min-w-0 pr-4">
                  <p className="text-[13px] font-semibold" style={{ color: "#F0F0FA" }}>{s.label}</p>
                  <p className="text-[11px]" style={{ color: "#6B6B84" }}>{s.desc}</p>
                </div>
                <button onClick={() => toggle(s.id)}>
                  {toggles[s.id] ? (
                    <div
                      className="w-11 h-6 rounded-full flex items-center justify-end pr-0.5 transition-all"
                      style={{ background: "linear-gradient(135deg, #C9A84C, #E8C97A)" }}
                    >
                      <div className="w-5 h-5 rounded-full" style={{ background: "#fff" }} />
                    </div>
                  ) : (
                    <div
                      className="w-11 h-6 rounded-full flex items-center justify-start pl-0.5"
                      style={{ background: "rgba(255,255,255,0.1)" }}
                    >
                      <div className="w-5 h-5 rounded-full" style={{ background: "rgba(255,255,255,0.4)" }} />
                    </div>
                  )}
                </button>
              </div>
            ))}
          </div>
        </div>

        {/* Menu items */}
        <div className="px-5 mb-5">
          <p className="text-[12px] font-semibold uppercase tracking-wider mb-3" style={{ color: "#6B6B84", letterSpacing: "0.1em" }}>
            Hesap & Daha Fazlası
          </p>
          <div
            className="rounded-2xl overflow-hidden"
            style={{ border: "1px solid rgba(255,255,255,0.07)" }}
          >
            {[
              { icon: Crown, label: "Üyelik Planım", desc: "Free · Yükselt", color: "#C9A84C", action: () => navigate("/pricing") },
              { icon: Gift, label: "Arkadaşını Davet Et", desc: "50 kredi kazan", color: "#B07DD9", action: () => {} },
              { icon: Star, label: "Uygulamayı Değerlendir", desc: "5 yıldız ver!", color: "#E8A830", action: () => {} },
              { icon: HelpCircle, label: "Yardım & Destek", desc: "SSS ve iletişim", color: "#4A90D9", action: () => {} },
              { icon: FileText, label: "Gizlilik Politikası", desc: "GDPR · KVKK", color: "#8A8A9E", action: () => {} },
              { icon: Shield, label: "Güvenlik", desc: "2FA ve güvenlik ayarları", color: "#3DBA8C", action: () => {} },
            ].map((item, i, arr) => (
              <button
                key={item.label}
                onClick={item.action}
                className="w-full flex items-center gap-3 px-4 py-3.5 transition-all"
                style={{
                  borderBottom: i < arr.length - 1 ? "1px solid rgba(255,255,255,0.05)" : "none",
                  background: i % 2 === 0 ? "rgba(255,255,255,0.02)" : "rgba(255,255,255,0.01)",
                }}
              >
                <div
                  className="w-9 h-9 rounded-xl flex items-center justify-center shrink-0"
                  style={{ background: `${item.color}15` }}
                >
                  <item.icon size={16} style={{ color: item.color }} />
                </div>
                <div className="flex-1 text-left min-w-0">
                  <p className="text-[13px] font-semibold" style={{ color: "#F0F0FA" }}>{item.label}</p>
                  <p className="text-[11px]" style={{ color: "#6B6B84" }}>{item.desc}</p>
                </div>
                <ChevronRight size={15} style={{ color: "#6B6B84", flexShrink: 0 }} />
              </button>
            ))}
          </div>
        </div>

        {/* GDPR actions */}
        <div className="px-5 mb-5">
          <div className="flex gap-2">
            <button
              className="flex-1 py-3 rounded-xl text-[12px] font-semibold flex items-center justify-center gap-2"
              style={{ background: "rgba(255,255,255,0.04)", border: "1px solid rgba(255,255,255,0.07)", color: "#8A8A9E" }}
            >
              <Share2 size={14} />
              Verilerimi İndir
            </button>
            <button
              className="flex-1 py-3 rounded-xl text-[12px] font-semibold flex items-center justify-center gap-2"
              style={{ background: "rgba(224,86,86,0.06)", border: "1px solid rgba(224,86,86,0.15)", color: "#E05656" }}
            >
              <Trash2 size={14} />
              Hesabı Sil
            </button>
          </div>
        </div>

        {/* Logout */}
        <div className="px-5 mb-6">
          <button
            onClick={() => navigate("/auth")}
            className="w-full py-3.5 rounded-2xl flex items-center justify-center gap-2 text-[14px] font-semibold"
            style={{ background: "rgba(255,255,255,0.04)", border: "1px solid rgba(255,255,255,0.07)", color: "#F0F0FA" }}
          >
            <LogOut size={16} style={{ color: "#E05656" }} />
            <span style={{ color: "#E05656" }}>Çıkış Yap</span>
          </button>
        </div>

        {/* Version */}
        <div className="px-5 pb-4 text-center">
          <p className="text-[11px]" style={{ color: "#4A4A5A" }}>
            OmniaPixels v1.0.0-rc · by OmniaCreata
          </p>
          <p className="text-[10px] mt-1" style={{ color: "#3A3A4A" }}>
            © 2026 Ali Erdinç Yiğitaslan · omniacreata.com
          </p>
        </div>
      </div>
    </div>
  );
}
