import { Outlet, useLocation } from "react-router";
import { BottomNav } from "./BottomNav";

const NAV_ROUTES = ["/home", "/gallery", "/queue", "/settings"];

export function Root() {
  const location = useLocation();
  const showNav = NAV_ROUTES.includes(location.pathname);

  return (
    <div
      className="min-h-screen w-full flex items-center justify-center"
      style={{ background: "radial-gradient(ellipse at center top, #1a1430 0%, #050508 60%)" }}
    >
      {/* Desktop studio background decoration */}
      <div className="fixed inset-0 pointer-events-none overflow-hidden">
        <div
          className="absolute top-1/3 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] rounded-full opacity-10"
          style={{ background: "radial-gradient(circle, #C9A84C 0%, transparent 70%)" }}
        />
      </div>

      {/* Phone frame */}
      <div
        className="relative flex flex-col overflow-hidden"
        style={{
          width: "min(390px, 100vw)",
          height: "min(844px, 100vh)",
          background: "#060608",
          borderRadius: "min(44px, 0px)",
          boxShadow: "0 0 0 1px rgba(255,255,255,0.06), 0 0 80px rgba(201,168,76,0.08), 0 40px 120px rgba(0,0,0,0.8)",
        }}
      >
        {/* Status bar */}
        <div className="absolute top-0 left-0 right-0 z-50 flex items-center justify-between px-6 pt-3 pb-1" style={{ height: "44px" }}>
          <span className="text-[11px] font-semibold" style={{ color: "#F0F0FA" }}>9:41</span>
          <div className="flex items-center gap-1">
            {/* Signal bars */}
            <svg width="17" height="12" viewBox="0 0 17 12" fill="none">
              <rect x="0" y="6" width="3" height="6" rx="1" fill="#F0F0FA" fillOpacity="0.9" />
              <rect x="4.5" y="4" width="3" height="8" rx="1" fill="#F0F0FA" fillOpacity="0.9" />
              <rect x="9" y="2" width="3" height="10" rx="1" fill="#F0F0FA" fillOpacity="0.9" />
              <rect x="13.5" y="0" width="3" height="12" rx="1" fill="#F0F0FA" fillOpacity="0.9" />
            </svg>
            {/* WiFi */}
            <svg width="16" height="12" viewBox="0 0 16 12" fill="none">
              <path d="M8 9.5C8.83 9.5 9.5 10.17 9.5 11S8.83 12.5 8 12.5 6.5 11.83 6.5 11 7.17 9.5 8 9.5Z" fill="#F0F0FA" fillOpacity="0.9" />
              <path d="M4 6.5C5.66 5.16 10.34 5.16 12 6.5" stroke="#F0F0FA" strokeOpacity="0.9" strokeWidth="1.3" strokeLinecap="round" />
              <path d="M1.5 3.5C4.5 1 11.5 1 14.5 3.5" stroke="#F0F0FA" strokeOpacity="0.9" strokeWidth="1.3" strokeLinecap="round" />
            </svg>
            {/* Battery */}
            <div className="flex items-center gap-[1px]">
              <div className="relative" style={{ width: "25px", height: "12px", border: "1.5px solid rgba(240,240,250,0.9)", borderRadius: "3px" }}>
                <div style={{ width: "70%", height: "100%", background: "#F0F0FA", borderRadius: "1.5px" }} />
              </div>
              <div style={{ width: "2px", height: "5px", background: "rgba(240,240,250,0.7)", borderRadius: "0 1px 1px 0" }} />
            </div>
          </div>
        </div>

        {/* Screen content */}
        <div
          className="flex-1 flex flex-col overflow-hidden relative"
          style={{ paddingTop: "44px", paddingBottom: showNav ? "80px" : "0" }}
        >
          <div className="flex-1 overflow-y-auto overflow-x-hidden omnia-scroll" style={{ scrollBehavior: "smooth" }}>
            <Outlet />
          </div>
        </div>

        {/* Bottom navigation */}
        {showNav && <BottomNav />}

        {/* Home indicator bar */}
        <div className="absolute bottom-1 left-1/2 -translate-x-1/2 w-28 h-1 rounded-full" style={{ background: "rgba(240,240,250,0.3)" }} />
      </div>
    </div>
  );
}
