import { useState } from "react";
import { useNavigate } from "react-router";
import { motion } from "motion/react";
import {
  Sparkles, Scissors, ZoomIn, Wand2, Palette, Eye,
  Bell, ChevronRight, Plus, Star, Zap, TrendingUp, Gift
} from "lucide-react";
import { ImageWithFallback } from "../figma/ImageWithFallback";

const PORTRAIT_URL = "https://images.unsplash.com/photo-1632776088367-d0709928731e?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwb3J0cmFpdCUyMHdvbWFuJTIwZ29sZGVuJTIwaG91ciUyMHBob3RvZ3JhcGh5fGVufDF8fHx8MTc3MjM4NzU4Mnww&ixlib=rb-4.1.0&q=80&w=400";
const CITY_URL = "https://images.unsplash.com/photo-1612005660669-006429efefff?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjaXR5JTIwbmlnaHQlMjBzdHJlZXQlMjBib2tlaCUyMHBob3RvZ3JhcGh5fGVufDF8fHx8MTc3MjM4NzU4Nnww&ixlib=rb-4.1.0&q=80&w=400";
const MOUNTAIN_URL = "https://images.unsplash.com/photo-1749401640206-19e74ab20409?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjaW5lbWF0aWMlMjBsYW5kc2NhcGUlMjBtb3VudGFpbiUyMGZvZyUyMGRyYW1hdGljfGVufDF8fHx8MTc3MjM4NzU4M3ww&ixlib=rb-4.1.0&q=80&w=400";

const quickActions = [
  { id: "enhance", icon: Sparkles, label: "AI Enhance", color: "#C9A84C", bg: "rgba(201,168,76,0.12)", credits: 1 },
  { id: "bg", icon: Scissors, label: "BG Sil", color: "#E05656", bg: "rgba(224,86,86,0.12)", credits: 2 },
  { id: "upscale", icon: ZoomIn, label: "Upscale", color: "#4A90D9", bg: "rgba(74,144,217,0.12)", credits: 2 },
  { id: "denoise", icon: Wand2, label: "Deblur", color: "#3DBA8C", bg: "rgba(61,186,140,0.12)", credits: 1 },
  { id: "style", icon: Palette, label: "Style", color: "#B07DD9", bg: "rgba(176,125,217,0.12)", credits: 3 },
  { id: "compare", icon: Eye, label: "Karşılaştır", color: "#E8A830", bg: "rgba(232,168,48,0.12)", credits: 0 },
];

const recentPhotos = [
  { id: 1, src: PORTRAIT_URL, type: "AI Enhanced", time: "2 saat önce", stars: true },
  { id: 2, src: CITY_URL, type: "BG Silindi", time: "Dün", stars: false },
  { id: 3, src: MOUNTAIN_URL, type: "4× Upscale", time: "3 gün önce", stars: true },
];

export function HomeScreen() {
  const navigate = useNavigate();
  const [credits] = useState(8);
  const maxCredits = 10;

  return (
    <div className="flex flex-col" style={{ background: "#060608", minHeight: "100%" }}>
      {/* Header */}
      <div className="px-5 pt-4 pb-3">
        <div className="flex items-center justify-between mb-5">
          <div>
            <p className="text-[12px] font-semibold tracking-widest uppercase" style={{ color: "#C9A84C", letterSpacing: "0.12em" }}>
              OmniaPixels
            </p>
            <h2 className="text-[20px] mt-0.5" style={{ fontWeight: 800, color: "#F0F0FA", letterSpacing: "-0.02em" }}>
              Merhaba, Ali 👋
            </h2>
          </div>
          <div className="flex items-center gap-2">
            <div
              className="relative w-9 h-9 rounded-xl flex items-center justify-center"
              style={{ background: "rgba(255,255,255,0.05)", border: "1px solid rgba(255,255,255,0.08)" }}
            >
              <Bell size={16} style={{ color: "#8A8A9E" }} />
              <div
                className="absolute top-1.5 right-1.5 w-2 h-2 rounded-full"
                style={{ background: "#C9A84C" }}
              />
            </div>
            <div
              className="w-9 h-9 rounded-xl flex items-center justify-center overflow-hidden"
              style={{ border: "1.5px solid rgba(201,168,76,0.4)" }}
            >
              <span className="text-[13px] font-bold" style={{ color: "#C9A84C" }}>AE</span>
            </div>
          </div>
        </div>

        {/* Credits card */}
        <motion.div
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.1 }}
          className="rounded-2xl p-4 relative overflow-hidden"
          style={{
            background: "linear-gradient(135deg, rgba(201,168,76,0.12) 0%, rgba(201,168,76,0.04) 100%)",
            border: "1px solid rgba(201,168,76,0.2)",
          }}
        >
          <div className="absolute top-0 right-0 w-32 h-32 rounded-full opacity-10"
            style={{ background: "radial-gradient(circle, #C9A84C 0%, transparent 70%)", transform: "translate(25%, -25%)" }} />
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-2">
              <div
                className="px-2.5 py-1 rounded-full text-[11px] font-bold tracking-wider uppercase"
                style={{ background: "rgba(201,168,76,0.2)", color: "#C9A84C", letterSpacing: "0.1em" }}
              >
                FREE
              </div>
              <span className="text-[13px]" style={{ color: "#8A8A9E" }}>Günlük Kredi</span>
            </div>
            <button
              onClick={() => navigate("/pricing")}
              className="flex items-center gap-1 px-3 py-1.5 rounded-full text-[12px] font-semibold"
              style={{ background: "rgba(201,168,76,0.15)", color: "#C9A84C", border: "1px solid rgba(201,168,76,0.25)" }}
            >
              <Zap size={11} />
              Pro'ya Geç
            </button>
          </div>
          <div className="flex items-end justify-between mb-2">
            <span className="text-[28px]" style={{ fontWeight: 800, color: "#F0F0FA" }}>{credits}</span>
            <span className="text-[14px] mb-1" style={{ color: "#6B6B84" }}>/ {maxCredits} kredi</span>
          </div>
          <div className="w-full h-2 rounded-full" style={{ background: "rgba(255,255,255,0.08)" }}>
            <motion.div
              className="h-full rounded-full"
              style={{ background: "linear-gradient(90deg, #C9A84C, #E8C97A)" }}
              initial={{ width: 0 }}
              animate={{ width: `${(credits / maxCredits) * 100}%` }}
              transition={{ duration: 0.8, delay: 0.3, ease: "easeOut" }}
            />
          </div>
          <div className="flex items-center gap-1.5 mt-2">
            <Gift size={12} style={{ color: "#C9A84C" }} />
            <span className="text-[11px]" style={{ color: "#8A8A9E" }}>Reklam izleyerek +5 kredi kazan</span>
          </div>
        </motion.div>
      </div>

      {/* Import CTA */}
      <div className="px-5 mb-4">
        <motion.button
          onClick={() => navigate("/editor")}
          className="w-full py-4 rounded-2xl flex items-center justify-center gap-3 relative overflow-hidden"
          style={{
            background: "linear-gradient(135deg, #C9A84C 0%, #E8C97A 50%, #C9A84C 100%)",
            boxShadow: "0 0 30px rgba(201,168,76,0.3), 0 4px 20px rgba(0,0,0,0.4)",
          }}
          whileTap={{ scale: 0.97 }}
        >
          <Plus size={20} style={{ color: "#060608" }} />
          <span className="text-[16px]" style={{ fontWeight: 700, color: "#060608" }}>
            Fotoğraf Ekle
          </span>
        </motion.button>
      </div>

      {/* Quick Actions */}
      <div className="px-5 mb-5">
        <div className="flex items-center justify-between mb-3">
          <h3 className="text-[15px]" style={{ fontWeight: 700, color: "#F0F0FA" }}>
            Hızlı Araçlar
          </h3>
          <button className="text-[12px]" style={{ color: "#C9A84C" }}>Tümü</button>
        </div>
        <div className="grid grid-cols-3 gap-3">
          {quickActions.map((action, i) => (
            <motion.button
              key={action.id}
              onClick={() => navigate("/editor")}
              className="flex flex-col items-center gap-2 p-3 rounded-2xl"
              style={{
                background: action.bg,
                border: `1px solid ${action.color}20`,
              }}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.4, delay: 0.15 + i * 0.06 }}
              whileTap={{ scale: 0.94 }}
            >
              <div
                className="w-10 h-10 rounded-xl flex items-center justify-center"
                style={{ background: `${action.color}18` }}
              >
                <action.icon size={20} style={{ color: action.color }} />
              </div>
              <span className="text-[11px] font-semibold text-center leading-tight" style={{ color: "#F0F0FA" }}>
                {action.label}
              </span>
              {action.credits > 0 && (
                <span className="text-[10px]" style={{ color: action.color }}>
                  {action.credits} kredi
                </span>
              )}
            </motion.button>
          ))}
        </div>
      </div>

      {/* AI Suggestion Banner */}
      <div className="px-5 mb-5">
        <motion.div
          className="rounded-2xl p-4 flex items-center gap-3 relative overflow-hidden"
          style={{
            background: "rgba(14,14,24,0.9)",
            border: "1px solid rgba(255,255,255,0.07)",
          }}
          initial={{ opacity: 0, x: -15 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.5, delay: 0.5 }}
        >
          <div className="absolute right-0 top-0 bottom-0 w-20" style={{ background: "linear-gradient(90deg, transparent, rgba(201,168,76,0.05))" }} />
          <div
            className="w-10 h-10 rounded-xl flex items-center justify-center shrink-0"
            style={{ background: "rgba(201,168,76,0.12)", border: "1px solid rgba(201,168,76,0.2)" }}
          >
            <TrendingUp size={18} style={{ color: "#C9A84C" }} />
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-[13px] font-semibold" style={{ color: "#F0F0FA" }}>AI Öneriyor</p>
            <p className="text-[11px] leading-snug mt-0.5" style={{ color: "#8A8A9E" }}>
              Son fotoğrafın için Upscale 2× önerilir
            </p>
          </div>
          <ChevronRight size={16} style={{ color: "#C9A84C", shrink: 0 }} />
        </motion.div>
      </div>

      {/* Recent edits */}
      <div className="px-5 mb-6">
        <div className="flex items-center justify-between mb-3">
          <h3 className="text-[15px]" style={{ fontWeight: 700, color: "#F0F0FA" }}>
            Son Düzenlemeler
          </h3>
          <button onClick={() => navigate("/gallery")} className="text-[12px]" style={{ color: "#C9A84C" }}>
            Tümünü Gör
          </button>
        </div>
        <div className="flex gap-3 overflow-x-auto pb-1" style={{ scrollbarWidth: "none" }}>
          {recentPhotos.map((photo, i) => (
            <motion.button
              key={photo.id}
              onClick={() => navigate("/compare")}
              className="relative rounded-2xl overflow-hidden shrink-0"
              style={{ width: "120px", height: "120px" }}
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.4, delay: 0.2 + i * 0.08 }}
              whileTap={{ scale: 0.95 }}
            >
              <ImageWithFallback
                src={photo.src}
                alt={photo.type}
                className="w-full h-full object-cover"
              />
              <div
                className="absolute inset-0"
                style={{ background: "linear-gradient(to top, rgba(6,6,8,0.85) 0%, transparent 50%)" }}
              />
              <div className="absolute bottom-2 left-2 right-2">
                <span
                  className="text-[10px] font-semibold px-1.5 py-0.5 rounded"
                  style={{ background: "rgba(201,168,76,0.8)", color: "#060608" }}
                >
                  {photo.type}
                </span>
              </div>
              {photo.stars && (
                <div className="absolute top-2 right-2">
                  <Star size={12} fill="#C9A84C" style={{ color: "#C9A84C" }} />
                </div>
              )}
            </motion.button>
          ))}
          {/* Add more card */}
          <button
            onClick={() => navigate("/editor")}
            className="rounded-2xl shrink-0 flex flex-col items-center justify-center gap-2"
            style={{
              width: "120px", height: "120px",
              background: "rgba(255,255,255,0.03)",
              border: "1.5px dashed rgba(255,255,255,0.12)",
            }}
          >
            <Plus size={22} style={{ color: "#6B6B84" }} />
            <span className="text-[11px]" style={{ color: "#6B6B84" }}>Yeni</span>
          </button>
        </div>
      </div>

      {/* Stats row */}
      <div className="px-5 mb-6">
        <div className="grid grid-cols-3 gap-3">
          {[
            { label: "Düzenlendi", value: "47", color: "#C9A84C" },
            { label: "Bu Hafta", value: "12", color: "#3DBA8C" },
            { label: "Kaydedilen", value: "23", color: "#4A90D9" },
          ].map((stat) => (
            <div
              key={stat.label}
              className="rounded-2xl p-3 text-center"
              style={{ background: "rgba(255,255,255,0.03)", border: "1px solid rgba(255,255,255,0.06)" }}
            >
              <div className="text-[22px]" style={{ fontWeight: 800, color: stat.color }}>{stat.value}</div>
              <div className="text-[11px] mt-0.5" style={{ color: "#6B6B84" }}>{stat.label}</div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
