import { useState } from "react";
import { useNavigate } from "react-router";
import { motion, AnimatePresence } from "motion/react";
import {
  ArrowLeft, RotateCcw, RotateCw, SlidersHorizontal, Sparkles,
  Scissors, ZoomIn, Wand2, Palette, Crop, ChevronRight, Check, Eye
} from "lucide-react";
import { ImageWithFallback } from "../figma/ImageWithFallback";

const PORTRAIT_URL = "https://images.unsplash.com/photo-1632776088367-d0709928731e?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwb3J0cmFpdCUyMHdvbWFuJTIwZ29sZGVuJTIwaG91ciUyMHBob3RvZ3JhcGh5fGVufDF8fHx8MTc3MjM4NzU4Mnww&ixlib=rb-4.1.0&q=80&w=400";

const tabs = [
  { id: "ai", label: "AI", icon: Sparkles },
  { id: "adjust", label: "Ayar", icon: SlidersHorizontal },
  { id: "filters", label: "Filtre", icon: Palette },
  { id: "crop", label: "Kırp", icon: Crop },
];

const aiTools = [
  { id: "enhance", icon: Sparkles, label: "AI Enhance", desc: "Otomatik iyileştir", credits: 1, color: "#C9A84C" },
  { id: "bg", icon: Scissors, label: "BG Sil", desc: "Arka plan kaldır", credits: 2, color: "#E05656" },
  { id: "upscale2", icon: ZoomIn, label: "Upscale 2×", desc: "Çözünürlük artır", credits: 2, color: "#4A90D9" },
  { id: "upscale4", icon: ZoomIn, label: "Upscale 4×", desc: "Pro gerektirir", credits: 4, color: "#4A90D9", pro: true },
  { id: "deblur", icon: Wand2, label: "Deblur", desc: "Netleştir", credits: 1, color: "#3DBA8C" },
  { id: "style", icon: Palette, label: "Style", desc: "Sanat modu", credits: 3, color: "#B07DD9", pro: true },
];

const adjustments = [
  { label: "Parlaklık", value: 20, min: -100, max: 100 },
  { label: "Kontrast", value: 10, min: -100, max: 100 },
  { label: "Doygunluk", value: 15, min: -100, max: 100 },
  { label: "Netlik", value: 0, min: -100, max: 100 },
  { label: "Beyaz Dengesi", value: -5, min: -100, max: 100 },
];

const filters = [
  { id: "none", label: "Orijinal", color: null },
  { id: "cinematic", label: "Sinematik", color: "#C9A84C" },
  { id: "vivid", label: "Canlı", color: "#E05656" },
  { id: "matte", label: "Mat", color: "#8A8A9E" },
  { id: "moody", label: "Moody", color: "#4A90D9" },
  { id: "warm", label: "Sıcak", color: "#E8A830" },
];

export function EditorScreen() {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState("ai");
  const [activeAiTool, setActiveAiTool] = useState<string | null>(null);
  const [activeFilter, setActiveFilter] = useState("none");
  const [processing, setProcessing] = useState(false);
  const [applied, setApplied] = useState(false);
  const [sliders, setSliders] = useState(adjustments.map(a => a.value));

  const applyAI = (toolId: string) => {
    if (processing) return;
    setActiveAiTool(toolId);
    setProcessing(true);
    setTimeout(() => {
      setProcessing(false);
      setApplied(true);
      setTimeout(() => setApplied(false), 2000);
    }, 2000);
  };

  return (
    <div className="flex flex-col" style={{ height: "calc(100vh - 44px)", background: "#060608" }}>
      {/* Top bar */}
      <div className="flex items-center justify-between px-4 py-3 shrink-0">
        <button
          onClick={() => navigate("/home")}
          className="w-9 h-9 rounded-xl flex items-center justify-center"
          style={{ background: "rgba(255,255,255,0.06)", border: "1px solid rgba(255,255,255,0.08)" }}
        >
          <ArrowLeft size={18} style={{ color: "#F0F0FA" }} />
        </button>
        <span className="text-[15px] font-bold" style={{ color: "#F0F0FA" }}>Editör</span>
        <div className="flex items-center gap-2">
          <button className="w-9 h-9 rounded-xl flex items-center justify-center"
            style={{ background: "rgba(255,255,255,0.06)", border: "1px solid rgba(255,255,255,0.08)" }}>
            <RotateCcw size={16} style={{ color: "#F0F0FA" }} />
          </button>
          <button className="w-9 h-9 rounded-xl flex items-center justify-center"
            style={{ background: "rgba(255,255,255,0.06)", border: "1px solid rgba(255,255,255,0.08)" }}>
            <RotateCw size={16} style={{ color: "#F0F0FA" }} />
          </button>
        </div>
      </div>

      {/* Image canvas */}
      <div className="relative flex-1 mx-4 rounded-2xl overflow-hidden" style={{ minHeight: 0, maxHeight: "280px" }}>
        <ImageWithFallback
          src={PORTRAIT_URL}
          alt="Edit"
          className="w-full h-full object-cover"
          style={{
            filter: applied
              ? "brightness(1.1) contrast(1.1) saturate(1.2)"
              : activeFilter === "cinematic"
              ? "sepia(0.2) contrast(1.1) brightness(0.95)"
              : activeFilter === "vivid"
              ? "saturate(1.5) contrast(1.1)"
              : activeFilter === "matte"
              ? "contrast(0.9) saturate(0.8) brightness(1.05)"
              : activeFilter === "moody"
              ? "brightness(0.85) contrast(1.2) saturate(0.7)"
              : "none",
            transition: "filter 0.4s ease",
          }}
        />

        {/* Processing overlay */}
        <AnimatePresence>
          {processing && (
            <motion.div
              className="absolute inset-0 flex flex-col items-center justify-center gap-3"
              style={{ background: "rgba(6,6,8,0.75)", backdropFilter: "blur(4px)" }}
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
            >
              <motion.div
                className="w-12 h-12 rounded-full border-2"
                style={{ borderColor: "rgba(201,168,76,0.3)", borderTopColor: "#C9A84C" }}
                animate={{ rotate: 360 }}
                transition={{ duration: 0.8, repeat: Infinity, ease: "linear" }}
              />
              <span className="text-[14px] font-semibold" style={{ color: "#F0F0FA" }}>
                AI işliyor...
              </span>
              <div className="flex gap-1">
                {[0, 1, 2].map((i) => (
                  <motion.div
                    key={i}
                    className="w-1.5 h-1.5 rounded-full"
                    style={{ background: "#C9A84C" }}
                    animate={{ opacity: [0.3, 1, 0.3] }}
                    transition={{ duration: 0.8, repeat: Infinity, delay: i * 0.2 }}
                  />
                ))}
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Applied badge */}
        <AnimatePresence>
          {applied && (
            <motion.div
              className="absolute top-3 right-3 flex items-center gap-1.5 px-3 py-1.5 rounded-full"
              style={{ background: "rgba(61,186,140,0.9)" }}
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.8 }}
            >
              <Check size={12} style={{ color: "#fff" }} />
              <span className="text-[12px] font-semibold" style={{ color: "#fff" }}>Uygulandı</span>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Compare & info overlays */}
        <button
          onClick={() => navigate("/compare")}
          className="absolute bottom-3 right-3 flex items-center gap-1.5 px-3 py-1.5 rounded-full"
          style={{ background: "rgba(0,0,0,0.6)", backdropFilter: "blur(8px)", border: "1px solid rgba(255,255,255,0.12)" }}
        >
          <Eye size={13} style={{ color: "#F0F0FA" }} />
          <span className="text-[12px] font-medium" style={{ color: "#F0F0FA" }}>Karşılaştır</span>
        </button>

        {/* AI type badge */}
        <div
          className="absolute top-3 left-3 px-2.5 py-1 rounded-full text-[11px] font-semibold"
          style={{ background: "rgba(201,168,76,0.85)", color: "#060608" }}
        >
          Portre Algılandı
        </div>
      </div>

      {/* Tabs */}
      <div className="px-4 mt-3 shrink-0">
        <div
          className="flex p-1 rounded-xl"
          style={{ background: "rgba(255,255,255,0.04)", border: "1px solid rgba(255,255,255,0.06)" }}
        >
          {tabs.map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className="flex-1 flex items-center justify-center gap-1.5 py-2 rounded-lg text-[12px] font-semibold transition-all"
              style={{
                background: activeTab === tab.id ? "rgba(201,168,76,0.15)" : "transparent",
                color: activeTab === tab.id ? "#C9A84C" : "#6B6B84",
              }}
            >
              <tab.icon size={13} />
              {tab.label}
            </button>
          ))}
        </div>
      </div>

      {/* Tool panel */}
      <div className="flex-1 px-4 py-3 overflow-y-auto omnia-scroll" style={{ minHeight: 0 }}>
        <AnimatePresence mode="wait">
          {activeTab === "ai" && (
            <motion.div
              key="ai"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0 }}
              className="grid grid-cols-2 gap-2.5"
            >
              {aiTools.map((tool) => (
                <button
                  key={tool.id}
                  onClick={() => !tool.pro && applyAI(tool.id)}
                  className="relative flex items-center gap-3 p-3 rounded-xl text-left"
                  style={{
                    background: activeAiTool === tool.id
                      ? `${tool.color}18`
                      : "rgba(255,255,255,0.04)",
                    border: activeAiTool === tool.id
                      ? `1px solid ${tool.color}40`
                      : "1px solid rgba(255,255,255,0.07)",
                    opacity: tool.pro ? 0.7 : 1,
                  }}
                >
                  {tool.pro && (
                    <div
                      className="absolute top-1.5 right-1.5 px-1.5 py-0.5 rounded text-[9px] font-bold"
                      style={{ background: "rgba(201,168,76,0.2)", color: "#C9A84C" }}
                    >
                      PRO
                    </div>
                  )}
                  <div
                    className="w-9 h-9 rounded-xl flex items-center justify-center shrink-0"
                    style={{ background: `${tool.color}18` }}
                  >
                    <tool.icon size={18} style={{ color: tool.color }} />
                  </div>
                  <div className="min-w-0">
                    <div className="text-[13px] font-semibold" style={{ color: "#F0F0FA" }}>{tool.label}</div>
                    <div className="text-[11px]" style={{ color: "#6B6B84" }}>{tool.credits} kredi</div>
                  </div>
                </button>
              ))}
            </motion.div>
          )}

          {activeTab === "adjust" && (
            <motion.div
              key="adjust"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0 }}
              className="flex flex-col gap-4"
            >
              {adjustments.map((adj, i) => (
                <div key={adj.label} className="flex flex-col gap-1.5">
                  <div className="flex justify-between">
                    <span className="text-[12px] font-semibold" style={{ color: "#A0A0B8" }}>{adj.label}</span>
                    <span className="text-[12px] font-bold" style={{ color: "#C9A84C" }}>{sliders[i] > 0 ? "+" : ""}{sliders[i]}</span>
                  </div>
                  <input
                    type="range"
                    min={adj.min}
                    max={adj.max}
                    value={sliders[i]}
                    onChange={(e) => {
                      const newSliders = [...sliders];
                      newSliders[i] = Number(e.target.value);
                      setSliders(newSliders);
                    }}
                    className="w-full h-1.5 rounded-full appearance-none cursor-pointer"
                    style={{
                      background: `linear-gradient(to right, #C9A84C ${((sliders[i] - adj.min) / (adj.max - adj.min)) * 100}%, rgba(255,255,255,0.1) ${((sliders[i] - adj.min) / (adj.max - adj.min)) * 100}%)`,
                      accentColor: "#C9A84C",
                    }}
                  />
                </div>
              ))}
            </motion.div>
          )}

          {activeTab === "filters" && (
            <motion.div
              key="filters"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0 }}
              className="grid grid-cols-3 gap-3"
            >
              {filters.map((filter) => (
                <button
                  key={filter.id}
                  onClick={() => setActiveFilter(filter.id)}
                  className="flex flex-col gap-2 items-center"
                >
                  <div
                    className="w-full rounded-xl overflow-hidden relative"
                    style={{
                      height: "70px",
                      border: activeFilter === filter.id ? "2px solid #C9A84C" : "2px solid transparent",
                    }}
                  >
                    <ImageWithFallback
                      src={PORTRAIT_URL}
                      alt={filter.label}
                      className="w-full h-full object-cover"
                      style={{
                        filter: filter.id === "cinematic" ? "sepia(0.2) contrast(1.1)" :
                          filter.id === "vivid" ? "saturate(1.5)" :
                          filter.id === "matte" ? "contrast(0.9) saturate(0.8)" :
                          filter.id === "moody" ? "brightness(0.8) contrast(1.2)" :
                          filter.id === "warm" ? "sepia(0.15) saturate(1.2)" : "none",
                      }}
                    />
                    {filter.color && (
                      <div className="absolute inset-0 opacity-20" style={{ background: filter.color }} />
                    )}
                  </div>
                  <span className="text-[11px] font-semibold" style={{ color: activeFilter === filter.id ? "#C9A84C" : "#8A8A9E" }}>
                    {filter.label}
                  </span>
                </button>
              ))}
            </motion.div>
          )}

          {activeTab === "crop" && (
            <motion.div
              key="crop"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0 }}
              className="flex flex-col gap-4"
            >
              <p className="text-[13px] text-center" style={{ color: "#6B6B84" }}>En-Boy Oranı Seç</p>
              <div className="grid grid-cols-4 gap-2">
                {[["Serbest", null], ["1:1", "square"], ["4:3", "landscape"], ["16:9", "wide"], ["9:16", "portrait"], ["3:2", "photo"], ["2:3", "portrait2"], ["5:4", "print"]].map(([label, _]) => (
                  <button
                    key={label}
                    className="py-2.5 rounded-xl text-[11px] font-semibold"
                    style={{
                      background: "rgba(255,255,255,0.04)",
                      border: "1px solid rgba(255,255,255,0.08)",
                      color: "#F0F0FA",
                    }}
                  >
                    {label}
                  </button>
                ))}
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* Bottom action bar */}
      <div className="px-4 pb-4 pt-2 shrink-0" style={{ borderTop: "1px solid rgba(255,255,255,0.06)" }}>
        <div className="flex gap-3">
          <button
            onClick={() => navigate("/home")}
            className="flex-1 py-3.5 rounded-2xl text-[15px] font-semibold"
            style={{ background: "rgba(255,255,255,0.06)", color: "#F0F0FA" }}
          >
            İptal
          </button>
          <button
            onClick={() => navigate("/export")}
            className="flex-1 py-3.5 rounded-2xl flex items-center justify-center gap-2 text-[15px] font-bold"
            style={{
              background: "linear-gradient(135deg, #C9A84C 0%, #E8C97A 100%)",
              color: "#060608",
              boxShadow: "0 0 20px rgba(201,168,76,0.3)",
            }}
          >
            Uygula
            <ChevronRight size={18} />
          </button>
        </div>
      </div>
    </div>
  );
}
