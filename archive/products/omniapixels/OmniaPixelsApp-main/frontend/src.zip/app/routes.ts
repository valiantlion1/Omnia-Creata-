import { createBrowserRouter } from "react-router";
import { Root } from "./components/layout/Root";
import { SplashScreen } from "./components/screens/SplashScreen";
import { OnboardingScreen } from "./components/screens/OnboardingScreen";
import { AuthScreen } from "./components/screens/AuthScreen";
import { HomeScreen } from "./components/screens/HomeScreen";
import { EditorScreen } from "./components/screens/EditorScreen";
import { QueueScreen } from "./components/screens/QueueScreen";
import { GalleryScreen } from "./components/screens/GalleryScreen";
import { CompareScreen } from "./components/screens/CompareScreen";
import { ExportScreen } from "./components/screens/ExportScreen";
import { PricingScreen } from "./components/screens/PricingScreen";
import { SettingsScreen } from "./components/screens/SettingsScreen";

export const router = createBrowserRouter([
  {
    path: "/",
    Component: Root,
    children: [
      { index: true, Component: SplashScreen },
      { path: "onboarding", Component: OnboardingScreen },
      { path: "auth", Component: AuthScreen },
      { path: "home", Component: HomeScreen },
      { path: "editor", Component: EditorScreen },
      { path: "queue", Component: QueueScreen },
      { path: "gallery", Component: GalleryScreen },
      { path: "compare", Component: CompareScreen },
      { path: "export", Component: ExportScreen },
      { path: "pricing", Component: PricingScreen },
      { path: "settings", Component: SettingsScreen },
    ],
  },
]);
