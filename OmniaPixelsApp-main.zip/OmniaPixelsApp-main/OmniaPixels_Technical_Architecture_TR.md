# OmniaPixels — Teknik Mimari (Genişletilmiş Tasarım Dokümanı, TR)

> Bu dosya **mühendis odaklı** ayrıntıları içerir: bileşenler, veri modeli, akışlar, karar politikaları, güvenlik, CI/CD, dağıtım, test, maliyet ve operasyon. Mobil + Backend + Kuyruk + Depolama + Router + ZeroCost tüm parçaları kapsar.

---

## 0) Sistem Özeti

- **İstemci:** Flutter mobil uygulama (Android/iOS).
- **API:** FastAPI (Python 3.11+).
- **Veri Katmanı:** PostgreSQL (SQLAlchemy/Alembic).
- **Kuyruk:** Redis + RQ (worker süreçleri).
- **Depolama:** S3-uyumlu (MinIO yerelde, AWS S3 bulutta).
- **Router:** Multi‑provider AI yönlendirici (local → bulut opsiyonel → ZeroCost fallback).
- **Telemetri:** `op_*` ve `zc_*` eventleri, Crash/Analytics.
- **CI/CD:** GitHub Actions (+ artefakt: `proof/`).
- **Dağıtım:** Lokal Docker Compose; Bulut (EC2 + S3 / ECS Fargate + S3 / RDS).
- **Güvenlik:** JWT, RBAC (admin/mod/user), rate‑limit, güvenli başlıklar, audit log, GDPR/KVKK akışları.

---

## 1) Bileşenler ve Sorumluluklar

### 1.1 Mobil (Flutter)
- **Modüller:** Onboarding, Auth, Editor Hub, Queue (progress), Gallery/Compare, Export/Share, Settings.
- **Özellikler:** EN/TR, Light/Dark (AMOLED ops), erişilebilirlik; FREE rozetli export; Drive Import/Export (opsiyonel).
- **Ağ:** REST over HTTPS; `Authorization: Bearer <JWT>`; download/upload presigned URL.

### 1.2 API (FastAPI)
- **Alt modüller:**
  - `auth`: register/login/refresh/me
  - `jobs`: enqueue/list/get/cancel
  - `storage`: presigned_put/presigned_get
  - `router`: provider test & metrics (opsiyonel yönetici uçları)
  - `admin`: feature-flags, api-keys vault (maskeli; rotate/revoke)
  - `health`: liveness `/health`, readiness `/readiness`
- **Cross‑cutting:** request id, structured logging (JSON), rate‑limit, CORS, security headers.

### 1.3 Worker’lar (RQ)
- **Kuyruklar:** `ai_processing`, `image_processing` (gelecekte `high`, `low` öncelikler).
- **İş akışı:** enqueued → started → (retry?) → finished/failed/canceled.
- **İş sınıfları:** upscale, denoise, sharpen, bg-remove, color/LUT, pipeline kombinasyonları.

### 1.4 Depolama (S3/MinIO)
- **Bucket örgüsü:** 
  - `raw/` (kullanıcıdan gelenler)
  - `jobs/<job_id>/inputs/`, `jobs/<job_id>/outputs/`
  - `exports/` (kullanıcıya hazır dosyalar)
  - `proof/` (isteğe bağlı kanıt aynası)
- **Presigned:** PUT (yükleme), GET (indirme); 5–30 dk TTL; `Content-MD5` doğrulaması (opsiyonel).

### 1.5 Router
- **Sağlayıcılar:** `local_vision` (yerel GPU/CPU), `local_llm` (judge/refactor), `cloud_*` (opsiyonel), `zero_cost` (hafif offline zincir).
- **Politika:** Cost‑Shield→Speed→QoS; başarısızlıkta degrade (sıradakine geç).

---

## 2) HTTP API (Örnek Şema)

Base: `/api/v1`

| Method | Path | Açıklama | Auth |
|---|---|---|---|
| GET | `/health` | Liveness | — |
| GET | `/readiness` | DB/Redis/S3 kontrolü | — |
| POST | `/auth/register` | e‑posta/şifre ile kayıt | — |
| POST | `/auth/login` | JWT access+refresh | — |
| GET | `/auth/me` | Kullanıcı bilgisi | Bearer |
| POST | `/jobs` | İş sıraya at: `{queue, params, input_uri}` | Bearer |
| GET | `/jobs` | Listeleme (sayfalı) | Bearer |
| GET | `/jobs/{id}` | Durum/çıkış link(ler)i | Bearer |
| POST | `/jobs/{id}/cancel` | İptal isteği | Bearer |
| POST | `/storage/presigned_put` | `{path_hint, content_type}` → URL | Bearer |
| POST | `/storage/presigned_get` | `{key}` → URL | Bearer |
| GET | `/admin/flags` | Feature flags | Admin |
| POST | `/admin/flags` | Flag güncelle | Admin |
| GET | `/router/providers` | Sağlayıcı durumu | Admin |

**Standart cevap zarfı:**
```json
{ "ok": true, "data": {...}, "error": null, "request_id": "uuid" }
```

---

## 3) Veri Modeli (ER Diyagram Özeti)

**Tablolar (ana alanlar):**
- `users`: id (uuid), email (uniq), password_hash, role, created_at
- `sessions`: id, user_id, refresh_token_hash, expires_at
- `plans`: id, code (FREE/PRO/ENT), limits_json
- `subscriptions`: id, user_id, plan_id, status, stripe_customer_id?, stripe_sub_id?
- `jobs`: id (uuid), user_id, queue, status, params_json, input_key, output_key, created_at, updated_at
- `job_events`: id, job_id, type (enqueued/started/progress/finished/failed/canceled), payload_json, ts
- `files`: id, user_id, key, content_type, size, sha256, created_at
- `api_keys`: id, hashed_key, label, last_used_at, revoked
- `feature_flags`: key (pk), value_json, updated_at
- `audit_logs`: id, actor_user_id?, action, object_type, object_id, meta_json, ts
- `router_logs`: id, job_id?, provider, latency_ms, cost_estimate, decision_meta, ts
- `quotas`: id, user_id, day, credits_used, credits_limit

**İndeks Önerileri:**
- `jobs(user_id, created_at desc)`; `job_events(job_id, ts)`; `files(user_id, created_at)`
- `router_logs(provider, ts)`; `subscriptions(user_id, status)`

---

## 4) İş Yaşam Döngüsü (State Machine)

Durumlar: `created → enqueued → started → (progress N%) → finished | failed | canceled`  
Geçiş kuralları:
- `cancel` sadece `enqueued` veya `started` durumunda mümkün.
- `failed` → retry (maks N, exponential backoff) → `enqueued`.
- `finished` olduğunda `output_key` zorunlu.

İdempotensi:
- `POST /jobs` için `Idempotency-Key` header’ı (opsiyonel). Aynı key ile gelen tekrarlar aynı job id’yi döndürür.

Zaman aşımları:
- Worker iş başına `TLE` (örn. 10 dk). Süre aşımında `failed(timeout)`.

---

## 5) AI Router — Karar Politikası

**Girdi:** iş türü, kullanıcı planı, cost_shield, provider_health, istek zorluğu  
**Çıktı:** seçilen sağlayıcı + parametreler

**Sözde Kod:**
```python
def choose_provider(ctx):
    if ctx.flags.cost_shield:
        order = ["local_vision", "zero_cost"]
    else:
        order = ["local_vision", "cloud_best", "zero_cost"]

    for p in order:
        if is_healthy(p) and supports(p, ctx.job_type):
            result = try_provider(p, ctx)
            log_router(ctx, p, result)
            if result.ok:
                return result
    return fallback_zero_cost(ctx)
```

**Sağlayıcı sağlığı:** son N çağrının latency/ok oranı; devre kesici (circuit‑breaker) eşikleri.  
**Maliyet hesabı:** local=0, cloud=sağlayıcı başına birim tahmin (yalnızca loglama).  
**QoS:** kalite puanı (opsiyonel, local_llm “judge”).

---

## 6) ZeroCost (Offline) İşlem Zinciri

**Zincir:** resize → denoise‑lite → sharpen‑lite (gerektiğinde bg‑remove lite).  
**Çerçeve:** plug‑in tasarım (her adım `fn(image, **params) -> image`).  
**Telemetri:** `zc_started`, `zc_progress(%, step)`, `zc_canceled`, `zc_finished` (job_events’e akar).  
**Parametre profilleri:** mobile’dan “Hızlı / Dengeli / Kalite” seçimleri; CPU/GPU destekli modlar.

Örnek YAML:
```yaml
zero_cost:
  preset: balanced
  steps:
    - name: resize
      width: 2048
    - name: denoise_lite
      strength: 0.3
    - name: sharpen_lite
      amount: 0.2
```

---

## 7) Depolama Tasarımı (S3/MinIO)

**Anahtar (key) şeması:**
```
raw/{user_id}/{yyyy}/{mm}/{dd}/{uuid}.{ext}
jobs/{job_id}/inputs/{n}.{ext}
jobs/{job_id}/outputs/final.{ext}
exports/{user_id}/{job_id}.{ext}
```

**Presigned PUT:** `Content-MD5` ve `Content-Type` zorunlu; 15 dk TTL.  
**Presigned GET:** 15 dk TTL; indirme sonrası erişim kesilebilir (ops).  
**S3 Lifecycle:** `jobs/*/inputs` 30 gün, `outputs` 180 gün, `exports` kalıcı (ops).

---

## 8) Güvenlik & Uyum

- **JWT:** HS256/RS256; access kısa (15–60 dk), refresh uzun (7–30 gün).  
- **Parola:** Argon2id veya bcrypt (work factor yükseltilmiş).  
- **RBAC:** admin/mod/user; admin uçları IP allowlist (ops).  
- **Rate limit:** IP ve user bazlı; `X-RateLimit-*` başlıkları.
- **Headers:** HSTS, X‑Content‑Type‑Options, X‑Frame‑Options, Referrer‑Policy.  
- **CORS:** mobil origin’leri; presigned için objeye özel izin.  
- **Audit log:** admin işlemleri; auth kritikleri.  
- **GDPR/KVKK:** `me/export` (JSON+zip), `me/delete` (soft→hard), retention politikaları.  
- **PII loglama:** e‑posta/isim maskelenir; tokenlar asla loglanmaz.

---

## 9) Gözlemlenebilirlik (Observability)

- **Log:** JSON biçim; `request_id`, `user_id?`, `route`, `latency_ms`, `status`.  
- **Metrik:** iş sayısı, bekleme süresi, başarısızlık oranı, provider latency/cost.  
- **Trace:** opsiyonel OpenTelemetry.  
- **Crash/Analytics (mobil):** Crashlytics/Sentry; event’ler: `op_*` (online), `zc_*` (offline).
- **Health/Readiness:** `/health` (liveness), `/readiness` (DB/Redis/S3).

---

## 10) CI/CD

**GitHub Actions (öneri job’ları):**
- `lint-test`: ruff + pytest + coverage; artefakt: `proof/`.
- `docker-build`: API ve worker imajları (tag: sha/branch).  
- `smoke-compose`: docker compose up → `/health` kontrol → job enqueue → presigned test.  
- `release`: RC tag’lama; `final_proof.zip` yükleme.

**Artefakt Yükleme:** `proof/**` (health.json, openapi.json, pytest.txt, coverage.xml, rq_lifecycle.log, minio_presigned.log, ekran görüntüleri).

---

## 11) Dağıtım (Deployment Topolojileri)

### 11.1 Lokal (0 TL)
- Docker Compose: `postgres`, `redis`, `minio`, `api`, `worker`  
- Portlar: 5432, 6379, 9000, 8000  
- Makefile: `up`, `down`, `migrate`, `smoke`

### 11.2 AWS – Ucuz Demo
- **EC2** tek makine: compose ile tüm stack.
- **S3**: kalıcı dosyalar.  
- **Route 53 + ACM**: domain/TLS.  
- **CloudWatch**: log/metrik.

### 11.3 AWS – Yönetilen (Büyüyünce)
- **ECS Fargate**: api/worker
- **RDS PostgreSQL**, **ElastiCache Redis**
- **ALB** + **WAF** + **CloudFront** (opsiyonel CDN)

---

## 12) Yapılandırma (Config Matrisi)

| Anahtar | Dev (lokal) | Staging (EC2+S3) | Prod |
|---|---|---|---|
| `APP_ENV` | `dev` | `staging` | `prod` |
| `API_BASE_URL` | `http://localhost:8000` | `https://staging.example.com` | `https://api.example.com` |
| `DATABASE_URL` | local PG | RDS/EC2 | RDS |
| `REDIS_URL` | local Redis | ElastiCache/EC2 | ElastiCache |
| `STORAGE_KIND` | `minio` | `s3` | `s3` |
| `COST_SHIELD` | `true` | `true` | `false` (kontrollü) |

`ops/env/.env.example` içinde yorumlu olarak sunulur.

---

## 13) Test Stratejisi

- **Unit:** modeller, yardımcı fonksiyonlar, router kararları (mock).  
- **API e2e:** register/login, jobs enqueue→status→output, presigned PUT/GET.  
- **Mobil widget/e2e:** akış ekranları; FREE badge.  
- **Performans:** 50 eşzamanlı job’ta kuyruk bekleme süresi, worker throughput.  
- **Dayanıklılık:** MinIO/S3 simüle hata; router fallback; retry/backoff.  
- **Güvenlik:** rate-limit, JWT süresi, RBAC, input doğrulama (pydantic).

---

## 14) Para & Kota (Monetizasyon Mantığı)

- **FREE:** günlük kredi; export’ta küçük “OmniaPixels” badge; daha yavaş kuyruk.  
- **PRO:** reklamsız; hızlı kuyruk; full çözünürlük.  
- **Quota Enforcement:** API gateway’de/DB’de; `429` ve kullanıcıya mesaj.  
- **Stripe Sandbox:** müşteri/abonelik; webhook ile `subscriptions` güncelle.

---

## 15) Admin & Feature Flags

- `feature_flags` tablosu: `zero_cost`, `marketplace`, `creator_studio`, `cost_shield` vs.  
- **Anlık etki:** flag okuma memory cache + kısa TTL; admin değiştirince invalidation.  
- **Key Vault:** AES‑256 at‑rest; maskeli görüntüleme; rotate/revoke; erişim audit log.

---

## 16) Hata Yönetimi ve Kenar Durumları

- **Idempotency-Key** ile tekrarlar → aynı job id.  
- **Presigned URL** süresi doldu → yeni URL üret.  
- **Büyük dosya** → çok parçalı yükleme (opsiyonel).  
- **İptal** → çalışan işçi iptal kontrol noktaları; kaynak temizliği.  
- **Çakışan port** → `.env`→ tek `API_BASE_URL`.  
- **Saat farklılığı** → server UTC, client local; JWT `nbf` toleransı.

---

## 17) Dizin Düzeni (Öneri)

```
backend/
  app/
    main.py
    deps.py
    api/v1/
      endpoints/ {auth.py, jobs.py, storage.py, health.py, admin.py}
    core/ {config.py, security.py, rate_limit.py}
    models/ {user.py, job.py, plan.py, ...}
    workers/ {ai_processing.py, image_processing.py}
    services/ {router.py, s3.py, minio.py}
  tests/ {unit/, e2e/}
mobile/
ops/ {docker-compose.yml, Makefile, env/}
proof/ {backend/, mobile_flows/, ai_router/, ops/}
docs/
scripts/
prompts/
.github/workflows/
```

---

## 18) Kabul Kriterleri (Definition of Done)

- `/health` ve `/readiness` **yeşil**.  
- `alembic upgrade head` **sorunsuz**.  
- `/jobs` uçları **e2e** geçiyor (enqueue→finish→download).  
- Presigned PUT/GET **çalışıyor**.  
- Mobil akış: seç→iş ver→%→indir **çalışıyor**.  
- **proof/** klasörü **dolu**; `final_proof.zip` var.  
- CI **yeşil**; yedek/restore notu mevcut; (opsiyonel) canlı URL açık.

---

## 19) Yol Haritası (Beta → 1.0)

- **Beta:** çekirdek + mobil akış + ZeroCost + router + kanıt + CI.  
- **RC:** push/email + free/pro + admin/flags + stripe sandbox.  
- **1.0:** bulut yayın (EC2+S3), domain/TLS, crash/analytics, Drive aynası.

---

**Ek:** Bu dokümanı repo’nun `docs/` klasörüne `TECH_DESIGN_TR.md` adıyla koyabiliriz; PR açıklamasına link eklenir.
