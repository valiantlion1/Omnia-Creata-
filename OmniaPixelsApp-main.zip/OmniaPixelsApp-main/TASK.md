# TASK

## Hedefler
- /health
- /api/v1/jobs (enqueue/list/get)
- MinIO presigned PUT/GET
- RQ (ai_processing, image_processing)

## Kabul
- testler geçer
- lint temiz
- openapi üretilir
- proof/ dolar
