# OmniaPixels - Repo Envanteri

## Klasör Ağacı
```
C:\Users\valiantlion\Desktop\OmniaPixelsApp-main\
├── .github/
│   └── workflows/
│       └── ci.yml
├── docs/
│   └── ENVANTER.md (bu dosya)
├── ops/
│   └── env/
│       └── .gitkeep
├── proof/ (boş - kanıt dosyaları buraya)
├── scripts/ (boş - otomasyon betikleri buraya)
├── .gitignore
├── TASK.md
├── OmniaPixels_FullStack_Plan_TR.md
├── OmniaPixels_Technical_Architecture_TR.md
└── *.docx dosyalar (blueprint, audit)
```

## Önemli Dosyalar
- **TASK.md**: Temel hedefler (/health, /api/v1/jobs, MinIO, RQ)
- **OmniaPixels_FullStack_Plan_TR.md**: Detaylı proje planı ve görev hattı
- **.gitignore**: ENV dosyaları ve proof/ klasörü hariç tutuluyor

## Port & URL Standartları
- **API Port**: 8000
- **API_BASE_URL**: http://localhost:8000 (ENV'den okunur)
- **Database**: PostgreSQL (port 5432)
- **Redis**: port 6379
- **MinIO**: port 9000

## TODO - Eksik Bileşenler
### Backend (Kritik)
- [ ] FastAPI uygulaması
- [ ] Models: users, jobs, job_events, files
- [ ] Routes: /health, /readiness, /auth, /api/v1/jobs, /storage
- [ ] Workers: ai_processing.py, image_processing.py
- [ ] Alembic migrations
- [ ] Unit & E2E testler

### Mobile (Kritik)
- [ ] Flutter uygulaması
- [ ] Ekranlar: Onboarding, Auth, Editor, Queue, Gallery, Settings
- [ ] Çoklu dil: EN/TR
- [ ] Tema: Light/Dark
- [ ] API entegrasyonu

### Ops (Kritik)
- [ ] docker-compose.yml (postgres, redis, minio, api, worker)
- [ ] Makefile (up, down, migrate, smoke)
- [ ] .env.example şablonu
- [ ] Smoke test betikleri

### CI/CD
- [ ] PR template
- [ ] Test coverage
- [ ] Proof artefakt toplama

## Açık Uçlar
1. **Cost Shield**: `COST_SHIELD=true` ENV değişkeni ile ücretli çağrılar devre dışı
2. **Kanıt Sistemi**: Tüm çıktılar proof/ klasörüne yazılacak
3. **Branch Stratejisi**: Her başlık ayrı branch + PR
4. **Test Gereksinimleri**: ≥3 unit + 1 e2e test zorunlu
