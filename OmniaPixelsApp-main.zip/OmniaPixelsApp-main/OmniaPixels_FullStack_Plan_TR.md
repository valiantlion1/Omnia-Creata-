# OmniaPixels — Çok-Ajan Full-Stack Uygulama Planı (TR)

> Bu dosya, OmniaPixels’i **mühendis olmayan** birinin de rahatça yönetebileceği şekilde özetler: ne yapıyoruz, hangi parçalar var, hangi sırayla bitecek, ajanlara ne yazılacak, kanıtlar neler, maliyet nasıl sıfıra yakın tutulur.

---

## 1) Amaç & Değer
- **Amaç:** Telefonda ve/veya bulutta görsel düzenleme/iyileştirme yapan, **ucuz, hızlı, her koşulda çalışan** bir uygulama.
- **Değer:** İnternet yokken de **ZeroCost (yerel)** çalışır; internet varsa **AI Router** ile en uygun yolu seçer. Free/Pro katmanları nettir.
- **Kanıt kültürü:** “Söz değil, çıktı.” Tüm ispatlar `proof/` klasörüne düşer.

---

## 2) Büyük Resim — “Fabrika” Benzetmesi
- **Mobil Uygulama (Flutter)** = Müşteri kapısı
- **API (FastAPI)** = Ön kapı / sipariş alan
- **Kuyruk (Redis + RQ)** = Fiş kesen sıra
- **İşçiler (Workers)** = Ustalar (görseli işler)
- **Depo (S3/MinIO)** = Dosyaların durduğu yer
- **Veritabanı (PostgreSQL)** = Kasadaki defter
- **AI Router** = Hangi ustayı seçeceğine karar veren şef
- **Presigned URL** = Kargocu link (tek kullanımlık yükle/indir)

**Akış:** Telefon → API → (Kuyruk) → Worker → (S3’e kaydet) → Telefon indirir

---

## 3) Ana Parçalar (15 Parça)
1. **Mobil Uygulama (Flutter)** – ekranlar: Onboarding, Editor, Queue(%), Gallery/Compare, Settings.  
   **Kanıt:** `proof/mobile_flows/*`
2. **API (FastAPI)** – `/auth`, `/health`, `/api/v1/jobs`, `/storage/presigned_*`.  
   **Kanıt:** `proof/backend/health.json`, `openapi.json`
3. **Kuyruk (Redis + RQ)** – uzun işler sıraya girer.  
   **Kanıt:** `proof/backend/rq_lifecycle.log`
4. **İşçiler (Workers)** – görüntü işleme (upscale/denoise/sharpen/bg remove).  
   **Kanıt:** giriş/çıkış örnekleri + log
5. **Depo (S3 veya MinIO)** – tek kullanımlık linklerle yükle/indir.  
   **Kanıt:** `proof/backend/minio_presigned.log`
6. **Veritabanı (PostgreSQL)** – kullanıcı/iş/plan kayıtları.  
   **Kanıt:** `proof/backend/migration.txt`
7. **Kimlik & Planlar (JWT + Free/Pro)** – Free rozet/kota, Pro sınırsız.  
   **Kanıt:** `proof/mobile_flows/free_badge_export.png`
8. **AI Router** – Yerel → (opsiyonel bulut) → (son çare) basit offline.  
   **Kanıt:** `proof/ai_router/router_log.jsonl`
9. **Mesajlaşma (Push & E-posta)** – job_done, kota uyarısı, duyuru, unsubscribe.  
   **Kanıt:** `proof/messaging/push_demo.mp4`, `email_unsubscribe.png`
10. **Ödeme/Abonelik (Stripe sandbox)** – Free→Pro, iptal→geri dönüş.  
    **Kanıt:** `proof/payments/stripe_webhook.log`
11. **Yönetim & Bayraklar (Admin/Dev Mode)** – API key kasası, rotate/revoke; feature flags (anında etki).  
    **Kanıt:** `proof/admin/*` kısa video + log
12. **Telemetri & Crash/Analytics** – `op_*`, `zc_*` olayları; çökme raporları.  
    **Kanıt:** `proof/*` + crash raporu görseli
13. **CI/CD & Operasyon** – test/lint/coverage, tek komut kalkış, yedek/restore.  
    **Kanıt:** `proof/ops/backup_restore.txt`, `ci_green.png`
14. **Yedek & Dışa Aktarım (GDrive aynası – opsiyonel)** – `proof/` ve export’lar Drive’a.  
    **Kanıt:** `proof/drive_sync_dryrun.txt`
15. **Yayınlama (Yerel → Bulut)** – evde tek makine; istersek EC2+S3.  
    **Kanıt:** Canlı `/health` URL’si + TLS notu

---

## 4) Sıralama — En Düşük Riskli Yol
1) **API + Kuyruk + İşçi + Depo** (çekirdek)  
2) **Mobil temel akış** (seç→iş ver→%→indir)  
3) **ZeroCost yerel işlemler** (internet yokken de çalışsın)  
4) **AI Router** (yerel→bulut→fallback; maliyet kalkanı açık)  
5) **Push/E-posta**, **Free/Pro**  
6) **Ödeme sandbox**, **Admin/Flags**  
7) **CI/CD + yedek + kanıt paketi**, (opsiyonel) **bulut yayın**

---

## 5) Çok-Ajan Stratejisi (Cursor/Codex/Windsurf/Qwen…)
- **Kör yarış:** Ajanlar birbirinden habersiz; herkes **kendi dalında**.
- **PASS0:** Repo/şablon/ignore/kanıt listesi (yapıldı).  
- **PASS1:** Modül üretimi (backend-core, mobile-skeleton, ci-proof, tests…).  
- **PASS2:** Sertleştirme (migration/readiness/smoke).  
- **MERGE:** Dalları tekleştir; çakışmaları çöz.  
- **JUDGE:** Yerel Qwen ile küçük düzeltmeler + rapor.

**Branch isimleri:** `agent/<arac-adi>/pass1-<modul>`  
**PR şablonu:** test≥3 + 1 e2e, lint temiz, manifest, artifacts(proof/).

---

## 6) Görev Hattı (G0→G10) — Full-Stack Bitiş
- **GÖREV 0:** Repo kilitle + envanter + standart (PR şablonu, klasörler, .gitignore, kanıt listesi).  
- **GÖREV 1:** Backend çekirdek (auth, jobs, MinIO/S3, RQ, docker-compose, test, proof).  
- **GÖREV 2:** Mobil iskelet (EN/TR, Light/Dark, FREE rozetli export).  
- **GÖREV 3:** Backend↔Mobil bağlama (login/register, job akışı, presigned GET).  
- **GÖREV 4:** ZeroCost offline zincir (resize→denoise-lite→sharpen-lite).  
- **GÖREV 5:** AI Router (yerel → bulut opsiyonel → fallback; cost_shield varsayılan açık).  
- **GÖREV 6:** Push + E-posta (quiet hours, unsubscribe; rapor ekranları).  
- **GÖREV 7:** Ödeme/abonelik (Stripe sandbox + webhook).  
- **GÖREV 8:** Admin/Dev mode + Key kasası + Flags (anlık etki).  
- **GÖREV 9:** CI/CD + Yedek/Restore + (opsiyonel) Tunnel/Domain/TLS.  
- **GÖREV 10:** Release Candidate + `final_proof.zip`.

> Her görev **tek PR**; `docs/NE_YAPTIM.md` içine 3–5 madde özet.

---

## 7) Kanıt (Proof) Kontrol Listesi
```
proof/backend/health.json
proof/backend/openapi.json
proof/backend/pytest.txt
proof/backend/coverage.xml
proof/backend/rq_lifecycle.log
proof/backend/minio_presigned.log
proof/mobile_flows/*.png / job_flow.mp4 / free_badge_export.png
proof/ai_router/router_log.jsonl
proof/messaging/push_demo.mp4
proof/messaging/email_unsubscribe.png
proof/payments/stripe_webhook.log
proof/admin/*.mp4 (veya .gif) + logs
proof/ops/backup_restore.txt
proof/ci_green.png
proof/final_proof.zip
```

---

## 8) Maliyet & Altyapı (0 TL → büyürse)
- **0 TL (yerel):** Docker Compose ile tek makine (Postgres, Redis, MinIO, API, Worker).  
- **Ucuza canlı demo:** 1 adet EC2/Lightsail + S3 (krediye dokunmadan düşük gider).  
- **Büyüyünce:** ECS Fargate, RDS, ElastiCache, CloudFront.  
- **Kalkan:** `cost_shield=true` → bulut çağrıları durdurulur; yerel/ZeroCost’tan yürür.

---

## 9) Güvenlik ve Gizlilik Notları
- **Sırlar .env’de**, koda gömülmez; PR’larda paylaşılamaz.  
- **Presigned URL** kısa ömürlü ve tek amaçlı linktir.  
- **Rate limit + CORS + güvenli başlıklar** API’de açık.  
- **GDPR/KVKK**: “Verimi indir/sil” akışları planlı.  
- **Bütçe alarmı** (AWS): Aylık 2$ uyarı limiti.

---

## 10) Kopyala-Yapıştır Prompt’lar (Ajanlar için)

**GLOBAL KURAL (her sohbette ilk satır):**
```
KURAL: Mevcut kodu silme/bozma; eksik yerleri tamamla. Gizli anahtar kullanma. Ücret çıkarma.
Çalıştığını kanıtlayan çıktıları proof/ klasörüne yaz. Her adım bittiğinde docs/NE_YAPTIM.md dosyasına 3–5 maddelik özet bırak.
```

**PASS1 — MODÜL ŞABLONU ({{MODUL}} değiştir):**
```
PASS1 / {{MODUL}} — kendi dalında çalış:
1) Branch: agent/<senin-adin>/pass1-{{MODUL}}
2) Gerekli kısımları uygula: 
   - Backend: /health, /auth(register/login/me), /api/v1/jobs(POST enqueue, GET list, GET /{id}), RQ worker lifecycle log
   - MinIO/S3 presigned PUT/GET
   - Mobil: Onboarding, Editor(placeholder), Queue(%), Gallery/Compare, Settings; EN/TR; Light/Dark; FREE rozetli export
   - Ops/CI: docker-compose (postgres, redis, minio, api, worker), Makefile (up, down, migrate, smoke), proof/ artefakt yükleme
3) Test: ≥3 unit + 1 e2e; Lint temiz
4) Kanıt: proof/** doldur
5) PR: "feat({{MODUL}}): PASS1 by <senin-adin>"
```

**PASS2 — Sertleştirme**
```
PASS2 / Sertleştirme:
- Alembic upgrade head sorunsuz
- Readiness JSON: DB/Redis/MinIO bağlantı süreleri ve status
- Compose smoke: up → /health → iş sıraya at → tamamlat → MinIO PUT/GET testleri → proof/backend/*
- PR: "chore: harden + smoke + readiness"
```

**MERGE**
```
MERGE:
- PASS1/2 PR’larını integration/main’e birleştir, çakışmaları çöz
- Test/lint çalıştır; docs/CHANGELOG.md yaz
- PR: "merge(pass1/2): integrate modules"
```

**JUDGE (yerel Qwen ile)**
```
JUDGE:
- docs/NE_YAPTIM.md + proof/** incele; eksikleri sırala
- Küçük düzeltmeleri yap (import/typo/test/port)
- docs/JUDGE_REPORT.md yaz
- PR: "fix(rc): judge pass"
```

---

## 11) Dizin Yapısı (öneri)
```
backend/            # FastAPI, models, routes, workers
mobile/             # Flutter app
ops/                # docker-compose, env şablonları, Makefile
proof/              # kanıt dosyaları (CI artefakt olarak toplanır)
docs/               # dökümantasyon
scripts/            # run_and_verify, drive_sync gibi betikler
prompts/            # görev metinleri (PASS1, PASS2, MERGE, JUDGE)
.github/workflows/  # CI
```

---

### Son söz
- Bu plana sadık kalırsak: **her adım ispatlı**, **maliyet kontrollü**, **çok-ajanlı** ve **tam otomasyon** bir full-stack çıkacak.  
- Ben buradayım: Her PR sonrası “Sıradaki Görev” metnini tek paragraf veririm; **sen sadece yapıştırırsın**.
