import os
import sys
import json
import logging
from datetime import datetime
from typing import Dict, Any
import io
from minio.error import S3Error

# Add parent directory to path for imports
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from app.database import SessionLocal
from app.models import Job, JobEvent, JobStatus
from app.storage import storage_service
from app.config import settings

# Setup logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


def log_lifecycle_event(message: str):
    """Log worker lifecycle events to proof file"""
    try:
        os.makedirs("proof/backend", exist_ok=True)
        with open("proof/backend/rq_lifecycle.log", "a") as f:
            f.write(f"[{datetime.utcnow().isoformat()}] AI_WORKER: {message}\n")
    except Exception as e:
        logger.error(f"Failed to write lifecycle log: {e}")


def update_job_status(job_id: int, status: JobStatus, message: str = None, output_key: str = None, error_message: str = None):
    """Update job status in database"""
    db = SessionLocal()
    try:
        job = db.query(Job).filter(Job.id == job_id).first()
        if job:
            job.status = status
            if output_key:
                job.output_key = output_key
            if error_message:
                job.error_message = error_message
            if status == JobStatus.COMPLETED:
                job.completed_at = datetime.utcnow()
            
            # Add job event
            event = JobEvent(
                job_id=job_id,
                event_type=status.value,
                message=message or f"Job {status.value}"
            )
            db.add(event)
            db.commit()
            
            log_lifecycle_event(f"Job {job_id} status updated to {status.value}")
    except Exception as e:
        logger.error(f"Failed to update job status: {e}")
        log_lifecycle_event(f"ERROR updating job {job_id}: {str(e)}")
    finally:
        db.close()


def process_ai(job_data: Dict[str, Any]):
    """Process AI job - placeholder implementation with cost shield and real S3 IO copy"""
    job_id = job_data['job_id']
    input_key = job_data['input_key']
    params = job_data.get('params', {})
    
    log_lifecycle_event(f"Starting AI processing job {job_id} with input {input_key}")
    
    try:
        # Update status to processing
        update_job_status(job_id, JobStatus.PROCESSING, "Starting AI processing")
        
        # Cost shield determines method label only (no external calls here)
        if settings.COST_SHIELD:
            processing_method = "local_fallback"
        else:
            processing_method = "cloud_ai"
        
        # Simulate AI processing time
        import time
        processing_time = params.get('processing_time', 5)
        time.sleep(processing_time)
        
        # Generate output key
        output_key = f"ai_processed_{input_key}"
        
        # Download from storage (supports local or MinIO)
        try:
            data, content_type = storage_service.get_bytes(input_key)
        except Exception as e:
            msg = f"Input not found or storage error for {input_key}: {e}"
            logger.error(msg)
            log_lifecycle_event(msg)
            update_job_status(job_id, JobStatus.FAILED, "Input missing", error_message=str(e))
            raise
        # Upload to storage (copy as-is)
        storage_service.put_bytes(
            output_key,
            data,
            content_type=content_type
        )
        
        log_lifecycle_event(f"AI processing completed for job {job_id} using {processing_method}, output {output_key}")
        
        # Update status to completed
        update_job_status(
            job_id, 
            JobStatus.COMPLETED, 
            f"AI processing completed successfully using {processing_method}",
            output_key=output_key
        )
        
        return {
            'job_id': job_id,
            'status': 'completed',
            'output_key': output_key,
            'processing_method': processing_method,
            'processing_time': processing_time,
            'cost_shield_active': settings.COST_SHIELD
        }
        
    except Exception as e:
        error_msg = str(e)
        logger.error(f"AI processing failed for job {job_id}: {error_msg}")
        log_lifecycle_event(f"ERROR in job {job_id}: {error_msg}")
        
        # Update status to failed
        update_job_status(
            job_id,
            JobStatus.FAILED,
            "AI processing failed",
            error_message=error_msg
        )
        
        raise


if __name__ == "__main__":
    # Test the worker
    test_job = {
        'job_id': 998,
        'input_key': 'test_ai_image.jpg',
        'params': {'processing_time': 2}
    }
    
    log_lifecycle_event("AI processing worker started (test mode)")
    result = process_ai(test_job)
    log_lifecycle_event(f"Test completed: {result}")
    print("AI processing worker test completed")
