﻿import os, sys, json, time, uuid
import requests
from urllib.parse import urlparse

API = "http://localhost:8000"
EMAIL = f"ceo_ai_{uuid.uuid4().hex[:8]}@example.com"
PASSWORD = "Passw0rd!"
PROOF_DIR = os.path.join("proof","backend")
os.makedirs(PROOF_DIR, exist_ok=True)

session = requests.Session()
headers = {"Content-Type": "application/json"}

def write_log(name, data):
    path = os.path.join(PROOF_DIR, name)
    with open(path, "w", encoding="utf-8") as f:
        if isinstance(data, (dict, list)):
            json.dump(data, f, indent=2)
        else:
            f.write(str(data))

# Try login; if fail, register then login
r = session.post(f"{API}/auth/login", json={"email": EMAIL, "password": PASSWORD}, headers=headers)
if r.status_code != 200:
    session.post(f"{API}/auth/register", json={"email": EMAIL, "password": PASSWORD}, headers=headers)
    r = session.post(f"{API}/auth/login", json={"email": EMAIL, "password": PASSWORD}, headers=headers)
r.raise_for_status()
auth = r.json()
access = auth.get("access_token")
session.headers.update({"Authorization": f"Bearer {access}"})

# Request presigned PUT for input
content = b"AI smoke payload: hello world!"
req = {"path_hint": "smoke_ai_input.txt", "content_type": "text/plain"}
r = session.post(f"{API}/storage/presigned_put", json=req)
r.raise_for_status()
res = r.json()
key = res["key"]
upload_url = res["upload_url"]

# Reroute technique for host mapping
u = urlparse(upload_url)
if u.hostname == "minio":
    effective = upload_url.replace("minio:9000", "localhost:9000")
    put_headers = {"Host": "minio:9000", "Content-Type": "text/plain"}
else:
    effective = upload_url
    put_headers = {"Content-Type": "text/plain"}

pr = requests.put(effective, data=content, headers=put_headers)
put_status = pr.status_code

# Enqueue AI job
job_payload = {
    "queue": "ai_processing",
    "input_key": key,
    "params": {"processing_time": 1, "note": "ai_smoke"}
}
r = session.post(f"{API}/api/v1/jobs", json=job_payload)
r.raise_for_status()
job = r.json()
job_id = job["id"]

# Poll until completed/failed
status = job["status"]
start = time.time()
while status not in ("completed","failed") and time.time() - start < 60:
    time.sleep(1)
    rr = session.get(f"{API}/api/v1/jobs/{job_id}")
    rr.raise_for_status()
    job = rr.json()
    status = job["status"]

result = job

# If completed, try presigned GET of output
download_bytes = None
if result.get("output_key"):
    r = session.post(f"{API}/storage/presigned_get", json={"key": result["output_key"]})
    r.raise_for_status()
    d = r.json()
    download_url = d["download_url"]
    du = urlparse(download_url)
    if du.hostname == "minio":
        effective_get = download_url.replace("minio:9000", "localhost:9000")
        get_headers = {"Host": "minio:9000"}
    else:
        effective_get = download_url
        get_headers = {}
    gr = requests.get(effective_get, headers=get_headers)
    download_bytes = len(gr.content) if gr.status_code == 200 else None

summary = {
    "email": EMAIL,
    "key": key,
    "put_status": put_status,
    "job_id": result.get("id"),
    "job_status": result.get("status"),
    "output_key": result.get("output_key"),
    "download_bytes": download_bytes
}

write_log("ai_job_result.json", result)
write_log("ai_job_summary.json", summary)
print(json.dumps(summary, indent=2))
